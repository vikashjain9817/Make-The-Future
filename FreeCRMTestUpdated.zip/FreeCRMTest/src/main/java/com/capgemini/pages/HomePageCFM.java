package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.base.TestBase;

public class HomePageCFM extends TestBase{
	
	@FindBy(xpath = "/html/body/div[2]/div/div[1]/a/img")
	WebElement im;
	
	//Initializing the Page Objects:
		public HomePageCFM(){
				PageFactory.initElements(driver, this);
		}
	
	public boolean getImageDetailsOfAfterLogin()
	{
		return im.isDisplayed();
	}

}
