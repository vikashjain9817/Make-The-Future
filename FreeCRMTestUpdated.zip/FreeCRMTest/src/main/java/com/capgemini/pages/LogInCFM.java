package com.capgemini.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.base.TestBase;

public class LogInCFM extends TestBase{
	
	@FindBy(xpath = "//*[@id=\"loginForm\"]/input[1]")
	WebElement email;
	
	@FindBy(xpath = "//*[@id=\"loginForm\"]/input[2]")
	WebElement pass;
	
	@FindBy(xpath = "//*[@id=\"loginForm\"]/input[3]")
	WebElement login;
	
	@FindBy(xpath = "//*[@id=\"ui\"]/div/div/div[2]/a")
	WebElement btn;
	
	
	//Initializing the Page Objects:
	public LogInCFM(){
			PageFactory.initElements(driver, this);
			btn.click();
	}
	
	
	public String getTitle()
	{
		return driver.getTitle();
	}
	
	//Actions:
		public String validateLoginPageTitle(){
			return driver.getTitle();
		}
	public HomePageCFM login(String user, String pwd)
	{
		email.sendKeys(user);
		pass.sendKeys(pwd);
		JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", login);
    	return new HomePageCFM();
	}
}
