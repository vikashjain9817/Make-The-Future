package com.capgemini.tests;

import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HomePage;
import com.capgemini.pages.LoginPage;

public class HomePageTest extends TestBase {

	
	static LoginPage loginPage;
	HomePage homePage;
	
	public HomePageTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@Test
	public void loginPortalImageTest() throws InterruptedException{
		homePage = loginPage.login("vikasjain9817@gmail.com", "vikash@0980");
		Thread.sleep(10000);
		assertTrue(homePage.checkImage());
	} 
	
	@AfterClass
	public static void tearup()
	{
		driver.quit();
	}
	
}
