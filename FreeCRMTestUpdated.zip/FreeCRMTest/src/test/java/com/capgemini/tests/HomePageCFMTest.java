package com.capgemini.tests;

import static org.testng.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HomePageCFM;
import com.capgemini.pages.LogInCFM;

public class HomePageCFMTest extends TestBase{
	
	static LogInCFM loginCFM;
	HomePageCFM homePageCFM;
	
	public HomePageCFMTest(){
		super();
	}

	@BeforeClass
	public static void setup()
	{
		initialization();
		loginCFM = new LogInCFM();
	}
	
	@Test
	public void testHomePageCFM() throws InterruptedException
	{
		homePageCFM = loginCFM.login("vikasjain9817@gmail.com", "vikash@0980");
		Thread.sleep(10000);
		assertTrue(homePageCFM.getImageDetailsOfAfterLogin());
		
	}
	
	@AfterClass
	public static void tearUp()
	{
		driver.quit();
	}
}
