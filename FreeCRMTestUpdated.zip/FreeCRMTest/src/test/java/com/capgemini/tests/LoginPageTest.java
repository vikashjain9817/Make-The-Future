package com.capgemini.tests;


import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.LoginPage;

public class LoginPageTest extends TestBase{
	static LoginPage loginPage;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@Test
	public void loginPageTitleTest(){
		String title = loginPage.validateLoginPageTitle();
		assertEquals(title, "CRM");
	}
	
	@AfterClass
	public static  void tearDown(){
		driver.quit();
	}

}