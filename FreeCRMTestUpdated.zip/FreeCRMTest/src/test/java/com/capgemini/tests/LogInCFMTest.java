package com.capgemini.tests;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HomePageCFM;
import com.capgemini.pages.LogInCFM;

public class LogInCFMTest extends TestBase{
	
	static LogInCFM loginCFM;
	static HomePageCFM homePageCFM;
	
	public LogInCFMTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginCFM = new LogInCFM();
	}
	
	@Test
	public void validateCFMTitle()
	{
		String title = loginCFM.validateLoginPageTitle();
		assertEquals(title, "CRMPRO Log In Screen");
	}
	
	@AfterClass
	public static void tearup()
	{
		driver.quit();
	}

}
