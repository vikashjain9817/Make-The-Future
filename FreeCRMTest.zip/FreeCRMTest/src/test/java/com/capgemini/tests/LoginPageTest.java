package com.capgemini.tests;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HomePage;
import com.capgemini.pages.LoginPage;

public class LoginPageTest extends TestBase{
	static LoginPage loginPage;
	HomePage homePage;
	
	public LoginPageTest(){
		super();
	}
	
	@BeforeClass
	public static void setUp(){
		initialization();
		loginPage = new LoginPage();	
	}
	
	@Test
	public void loginPageTitleTest(){
		String title = loginPage.validateLoginPageTitle();
		assertEquals(title, "Cogmento CRM");
	}
	
	@Test
	public void loginTest() throws InterruptedException{
		homePage = loginPage.login("vikasjain9817@gmail.com", "vikash@0980");
		assertTrue(homePage instanceof HomePage);
		Thread.sleep(5000);
	}
	
	
	
	@AfterClass
	public static  void tearDown(){
		driver.quit();
	}
	
	
	
	

}