package com.capgemini.pages;

public class HomePage {

}
